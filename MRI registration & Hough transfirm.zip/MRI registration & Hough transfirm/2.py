import numpy as np
import cv2 
from matplotlib import pyplot as plt
###########a






# Read image as gray-scale
img = cv2.imread('coins.png', cv2.IMREAD_COLOR)
# Convert to gray-scale
gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)

_,thresh=cv2.threshold(gray,20,1,cv2.THRESH_BINARY_INV)
plt.figure("tophat")
plt.imshow(thresh,cmap="gray")
plt.title('BINARY_INV')

kernel = np.ones((9,9),np.uint8)

mask = cv2.dilate(thresh,kernel,iterations = 1)

plt.figure("mask_1")
plt.imshow(mask,cmap="gray")







#
#kernel_2 = np.ones((3,3),np.uint8)
#
#mask = cv2.morphologyEx(mask, cv2.MORPH_CLOSE, kernel)

plt.figure("mask_2")
plt.imshow(mask,cmap="gray")



im_canny=cv2.Canny(gray,100,200)
plt.figure('canny')

plt.imshow(im_canny,cmap = 'gray')
plt.title('Canny')


img_blur = im_canny*mask

plt.figure('masked')
plt.imshow(img_blur,cmap = 'gray')
plt.title('masked')

# Apply hough transform on the image
circles = cv2.HoughCircles(img_blur, cv2.HOUGH_GRADIENT, 1, img.shape[0]/64, param1=200, param2=10, minRadius=7, maxRadius=11)


# liminatet close circles









# Draw detected circles
if circles is not None:
    circles = np.uint16(np.around(circles))
    for i in circles[0, :]:
        # Draw outer circle
        if i[2]<=9:
            
            cv2.circle(img, (i[0], i[1]), i[2], (255, 0, 0), 1)
            # Draw inner circle
            cv2.circle(img, (i[0], i[1]), 2, (255, 0, 0), 1)
        if i[2]>9:
            cv2.circle(img, (i[0], i[1]), i[2], (0, 0, 255), 1)
            # Draw inner circle
            cv2.circle(img, (i[0], i[1]), 2, (0, 0, 255), 1)
            
plt.figure('2')

plt.imshow(img,cmap='gray')