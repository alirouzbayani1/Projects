import cv2 
import numpy as np 
from matplotlib import pyplot as plt

  
img1_color = cv2.imread("MRI2.png")  
img_distorted = cv2.cvtColor(img1_color, cv2.COLOR_BGR2GRAY) 


img2_color = cv2.imread("MRI1_s.png")  
img_reference = cv2.cvtColor(img2_color, cv2.COLOR_BGR2GRAY) 


##
#paded=np.zeros((np.shape(img2)[0],np.shape(img2)[1]),dtype=int)
#paded[102:102+217,180:179+182]=img1

#scale_percent = 100 
#width = int(img2.shape[1] * scale_percent / 100)
#height = int(img2.shape[0] * scale_percent / 100)
#dim = (width, height)
## resize image
#img1 = cv2.resize(img1, dim, interpolation = cv2.INTER_AREA)
#


orb=cv2.ORB_create(5000)



kp1,des1=orb.detectAndCompute(img_distorted, None)
kp2,des2=orb.detectAndCompute(img_reference, None)



img1_orb=cv2.drawKeypoints(img_distorted,kp1,None,flags=None)

img2_orb=cv2.drawKeypoints(img_reference,kp2,None,flags=None)


plt.figure('reference')
plt.imshow(img1_orb,cmap='gray')

plt.figure('distorted')
plt.imshow(img2_orb,cmap='gray')


matcher=cv2.DescriptorMatcher_create(cv2.DESCRIPTOR_MATCHER_BRUTEFORCE_HAMMING)

matches=matcher.match(des1,des2,None)
mathces=sorted(matches,key=lambda x:x.distance)


img_matches=cv2.drawMatches(img_distorted,kp1,img_reference,kp2,matches,None)

plt.figure('matches')
plt.imshow(img_matches,cmap='gray')


points1=np.zeros((len(matches),2),dtype=np.float32)
points2=np.zeros((len(matches),2),dtype=np.float32)


for i , match in enumerate(matches):
    points1[i,:]=kp1[match.queryIdx].pt
    points2[i,:]=kp2[match.trainIdx].pt



h,mask=cv2.findHomography(points1,points2,cv2.RANSAC)




height,width,chanels=np.shape(img2_color)

im1_reg=cv2.warpPerspective(img_distorted,h,(width,height))


plt.figure('final')
plt.imshow(im1_reg,cmap='gray')


#x, y = a.pt





