import numpy as np
import cv2 as cv
from matplotlib import pyplot as plt 

bone=cv.imread('C:/Users/SONY/Desktop/dip/hw2-karshenasi/bone-scan.png')
bone=cv.cvtColor(bone, cv.COLOR_BGR2GRAY)

plt.figure('original')
plt.imshow(bone,cmap="gray")

############a

bone_paded=np.pad(bone,pad_width=1,mode='constant',constant_values=0)

row,col=np.shape(bone_paded)

bone_m=[]

for i in np.linspace(1,row-2,row-2,dtype=int):
    for j in np.linspace(1,col-2,col-2,dtype=int):
        mask=bone_paded[i-1:i+2,j-1:j+2]
        m=np.median(mask)
        bone_m.append(m)
        
ans_m=np.reshape(bone_m , (row-2,col-2) )
plt.figure("median")
plt.imshow(ans_m,cmap="gray")        
        

#############b

lap=([1,1,1],[1,-8,1],[1,1,1])
bone_l=[]

ans_m_paded=np.pad(ans_m,pad_width=1,mode='constant',constant_values=0)


for i in np.linspace(1,row-2,row-2,dtype=int):
    for j in np.linspace(1,col-2,col-2,dtype=int):
        mask=ans_m_paded[i-1:i+2,j-1:j+2]
        l=np.sum(np.multiply(mask,lap))
        bone_l.append(l)
        
ans_l=np.reshape(bone_l , (row-2,col-2) )
#ans_l=np.multiply(ans_l,255/2040)


cv.imshow('laplacian_filter' , np.array(ans_l, dtype = np.uint8 ) )

############c

im_enhanced=ans_m+np.multiply(ans_l,-1)

plt.figure('laplacian applied')
plt.imshow(im_enhanced,cmap="gray")



#############d

sobel_x=([-1,-2,-1],[0,0,0],[1,2,1])
sobel_y=([-1,0,1],[-2,-0,2],[-1,0,1])

bone_s_x=[]
bone_s_y=[]

for i in np.linspace(1,row-2,row-2,dtype=int):
    for j in np.linspace(1,col-2,col-2,dtype=int):
        mask=ans_m_paded[i-1:i+2,j-1:j+2]
        x=np.sum(np.multiply(mask,sobel_x))
        y=np.sum(np.multiply(mask,sobel_y))
        bone_s_x.append(x)
        bone_s_y.append(y)
        
        
bone_s_x=np.reshape(bone_s_x , (row-2,col-2) )
bone_s_y=np.reshape(bone_s_x , (row-2,col-2) )

im_sobel=np.sqrt(np.power(bone_s_x,2)+np.power(bone_s_y,2))

plt.figure("sobel")
plt.imshow(im_sobel,cmap="gray")


#############e

smooth=np.ones([5,5])*1/25
im_sobel_paded=np.pad(im_sobel,pad_width=2,mode='constant',constant_values=0)
row_s,col_s=np.shape(im_sobel_paded)

im_smooth=[]

for i in np.linspace(2,row-2,row-2,dtype=int):
    for j in np.linspace(2,col-2,col-2,dtype=int):
        mask=im_sobel_paded[i-2:i+3,j-2:j+3]
        s=np.sum(np.multiply(mask,smooth))
        im_smooth.append(s)
        
im_smooth=np.reshape(im_smooth , (row-2,col-2) )

plt.figure('smoothed')
plt.imshow(im_smooth,cmap="gray")

################f g


mask_f=np.multiply(im_sobel,ans_l)
mask_f[mask_f<0]=0
mask_f = [x *(255/60188) for x in mask_f]

im_f=ans_m+mask_f
plt.figure("mask_F")
plt.imshow(mask_f,cmap="gray")

plt.figure("mask f applied")
plt.imshow(im_f,cmap="gray")

##############h

im_final=np.power(im_f,0.5)
plt.figure("final")
plt.imshow(im_final,cmap="gray")















