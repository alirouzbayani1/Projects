import numpy as np
import cv2 as cv
import matplotlib.pyplot as plt

###########a



path='C:/Users/SONY/Desktop/dip/hw2-karshenasi/head.png';

head=cv.imread(path)

head=cv.cvtColor(head, cv.COLOR_BGR2GRAY)

def intToBitArray(img) :
    
    list = []
    row ,col = np.shape(img)
    
    for p in np.linspace(0,7,8,dtype=int):
        for i in range(row):
            for j in range(col):
                temp=np.binary_repr( img[i][j] ,width=8)
                temp=int(temp)
                temp=temp/pow(10,p)
                temp=int(temp)%10
                list.append (temp)



    ans = np.reshape(list , (8,row,col) )
    
    return ans

x=intToBitArray(head)

x_uint8=x*255;

plt.figure()
for i in np.linspace(0,7,8,dtype=int):
    plt.subplot(2,4,8-i)
    plt.imshow(x_uint8[:][:][i],cmap="gray")

##########b


new_2=np.zeros(np.shape(head))
new_2=x[:][:][7]*128+x[:][:][6]*64
new_4=new_2+x[:][:][5]*32+x[:][:][4]*16

plt.figure()
plt.subplot(2,1,1)
plt.imshow(new_2,cmap="gray")
plt.subplot(2,1,2)
plt.imshow(new_4,cmap="gray")
 
