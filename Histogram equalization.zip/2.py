import cv2 as cv
import numpy as np
from matplotlib import pyplot as plt

#############a

img = cv.imread('C:/Users/SONY/Desktop/dip/hw2-karshenasi/spine.tif')

img_log_1 = (np.log(img+0.9)/(np.log(1+np.max(img))))*255
img_log_2 = (np.log(img+0.4)/(np.log(1+np.max(img))))*255


img_log_1 = np.array(img_log_1,dtype=np.uint8)
img_log_2= np.array(img_log_2,dtype=np.uint8)

plt.figure("log with parameters")
plt.subplot(3,2,1)
plt.imshow(img,cmap="gray")
plt.subplot(3,2,2)
plt.hist(img.ravel(),256,[0,256]); 
plt.subplot(3,2,3)
plt.imshow(img_log_1,cmap="gray")
plt.subplot(3,2,4)
plt.hist(img_log_1.ravel(),256,[0,256]); 
plt.subplot(3,2,5)
plt.imshow(img_log_2,cmap="gray")
plt.subplot(3,2,6)
plt.hist(img_log_2.ravel(),256,[0,256]); 


##############b

kidney=cv.imread('C:/Users/SONY/Desktop/dip/hw2-karshenasi/kidney.tif')
kidney=cv.cvtColor(kidney, cv.COLOR_BGR2GRAY)

row,column = np.shape(kidney)

img1 = np.zeros((row,column),dtype = 'uint8')
 
A_1 = 160
B_1 = 240
 
for i in range(row):
    for j in range(column):
        if kidney[i,j]>A_1 and kidney[i,j]<B_1:
            img1[i,j] = 150
        else:
            img1[i,j] = 20
            
plt.figure("sliced_1")
plt.imshow(img1,cmap="gray")


img2 = np.zeros((row,column),dtype = 'uint8')

A_2 = 100
B_2 = 165
 
for i in range(row):
    for j in range(column):
        if kidney[i,j]>A_2 and kidney[i,j]<B_2:
            img2[i,j] = 200
        else:
            img2[i,j] = kidney[i,j]
            
plt.figure("sliced_2")
plt.imshow(img2,cmap="gray")

cv.waitKey(0)