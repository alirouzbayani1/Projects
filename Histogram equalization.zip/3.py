import numpy as np
import cv2 as cv
from matplotlib import pyplot as plt


############a

path='C:/Users/SONY/Desktop/dip/hw2-karshenasi/spine.tif'
img=cv.imread(path)
img=cv.cvtColor(img, cv.COLOR_BGR2GRAY)


def hist(img) :
    
    hist=[0]*256
    
    row ,col = np.shape(img)
    
    for i in range(row):
        for j in range(col):
            a=int(img[i][j])
            hist[a]=hist[a]+1
           
    return hist

x=np.linspace(0,255,256,dtype=int)
a=hist(img)

plt.figure('hist')
plt.bar(x,a)

#############b

low=cv.imread('C:/Users/SONY/Desktop/dip/hw2-karshenasi/Lowcontrast.tif')
low=cv.cvtColor(low, cv.COLOR_BGR2GRAY)
white=cv.imread('C:/Users/SONY/Desktop/dip/hw2-karshenasi/White.tif')
white=cv.cvtColor(white, cv.COLOR_BGR2GRAY)
dark=cv.imread('C:/Users/SONY/Desktop/dip/hw2-karshenasi/Dark.tif')
dark=cv.cvtColor(dark, cv.COLOR_BGR2GRAY)


low_mn=(np.shape(low)[0]*np.shape(low)[1])
low_hist=hist(low)
low_hist_normalized = [x / low_mn for x in low_hist]
plt.figure('low_contrast histrogram')
plt.bar(x,low_hist_normalized)


white_mn=(np.shape(white)[0]*np.shape(white)[1])
white_hist=hist(white)
white_hist_normalized = [x / white_mn for x in white_hist]
plt.figure('white histogram')
plt.bar(x,white_hist_normalized)


dark_mn=(np.shape(dark)[0]*np.shape(dark)[1])
dark_hist=hist(dark)
dark_hist_normalized = [x / dark_mn for x in dark_hist]
plt.figure('dark histogram')
plt.bar(x,dark_hist_normalized)

##############c

def hist_equalization(img) :
    
    row ,col = np.shape(img)
    eq_im=np.zeros((row,col))
    
    mn=(row*col)
    hist_1=hist(img)
    hist_1 = [x / mn for x in hist_1]
    hist_sum=np.cumsum(hist_1)
    
    
    for i in range(row):
        for j in range(col):
            a=img[i][j]
            eq_im[i][j]=int((255*hist_sum[a]))
           
    return eq_im

e=hist_equalization(img)


##############d



dark_hist=hist(dark)
dark_eq=hist_equalization(dark)
dark_hist_eq=hist(dark_eq)

white_hist=hist(white)
white_eq=hist_equalization(white)
white_hist_eq=hist(white_eq)

low_hist=hist(low)
low_eq=hist_equalization(low)
low_hist_eq=hist(low_eq)

plt.figure("equalized images and histograms")
plt.subplot(3,4,1)
plt.imshow(dark,cmap="gray")
plt.subplot(3,4,2)
plt.bar(x,dark_hist)
plt.subplot(3,4,3)
plt.imshow(dark_eq,cmap="gray")
plt.subplot(3,4,4)
plt.bar(x,dark_hist_eq)

plt.subplot(3,4,5)
plt.imshow(white,cmap="gray")
plt.subplot(3,4,6)
plt.bar(x,white_hist)
plt.subplot(3,4,7)
plt.imshow(white_eq,cmap="gray")
plt.subplot(3,4,8)
plt.bar(x,white_hist_eq)

plt.subplot(3,4,9)
plt.imshow(low,cmap="gray")
plt.subplot(3,4,10)
plt.bar(x,low_hist)
plt.subplot(3,4,11)
plt.imshow(low_eq,cmap="gray")
plt.subplot(3,4,12)
plt.bar(x,low_hist_eq)





                                                                          
