%loading images
t1_rgb=imread('t1_t2_p\t1.png');
t2_rgb=imread('t1_t2_p\t2.png');
flair_rgb=imread('t1_t2_p\prt.png');
t1=rgb2gray(t1_rgb);
t2=rgb2gray(t2_rgb);
flair=rgb2gray(flair_rgb);
%
figure(1)
subplot(1,3,1)
imshow(t1)
subplot(1,3,2)
imshow(t2)
subplot(1,3,3)
imshow(flair)
%visualizing points
figure(2)
plot3(t1(:),t2(:),flair(:),'.')
t1_col=t1(:);
t2_col=t2(:);
flair_col=flair(:);
data=zeros(size(t1(:),1),3);
data(:,1)=t1(:);
data(:,2)=t2(:);
data(:,3)=flair(:);
[idx,centers]=kmeans(data,5);
index_c1=find(idx==1);
index_c2=find(idx==2); 
index_c3=find(idx==3);
index_c4=find(idx==4);
index_c5=find(idx==5);
figure(4)
hold on;
scatter3(centers(:,1),centers(:,2),centers(:,3),'*');
scatter3(t1_col(index_c2),t2_col(index_c2),flair_col(index_c2),'b','.');
scatter3(t1_col(index_c1),t2_col(index_c1),flair_col(index_c1),'r','.');
scatter3(t1_col(index_c3),t2_col(index_c3),flair_col(index_c3),'g','.');
scatter3(t1_col(index_c4),t2_col(index_c4),flair_col(index_c4),'y','.');
scatter3(t1_col(index_c5),t2_col(index_c5),flair_col(index_c5),'p','.');

%segmentation of 3d image
t1_seg_col=zeros(size(t1(:)));
t1_seg_col(index_c1)=1;
t1_seg_col(index_c2)=0;
t1_seg_col(index_c3)=0;
t1_seg_col(index_c4)=1;
t1_seg_col(index_c5)=0;
t1_seg=reshape(t1_seg_col,size(t1,1),size(t1,2));
figure(10)
imshow(t1_seg);
%segmentation of t1
