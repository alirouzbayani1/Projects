import numpy as np
import cv2 as cv
import matplotlib.pyplot as plt


path='brain.tif';
img=cv.imread(path)
img=cv.cvtColor(img, cv.COLOR_BGR2GRAY)
kernel = np.ones((5,5),np.uint8)

########gradient


img_erode = cv.erode(img,kernel,iterations = 1)
img_dialated = cv.dilate(img,kernel,iterations = 1)
img_gradient=img_dialated-img_erode

plt.figure("gradient")
plt.imshow(img_gradient,cmap="gray")
plt.title('Gradient')


##########top hat

path_rice='rice.tif';
rice=cv.imread(path_rice)
rice=cv.cvtColor(rice, cv.COLOR_BGR2GRAY)
kernel_2 = np.ones((20,20),np.uint8)
tophat = cv.morphologyEx(rice, cv.MORPH_TOPHAT, kernel_2)

kernel_3 = np.ones((7,7),np.uint8)

_,tophat_thresh=cv.threshold(tophat,20,255,cv.THRESH_BINARY)
final= cv.morphologyEx(tophat_thresh, cv.MORPH_CLOSE, kernel_3)
plt.figure("tophat")
plt.imshow(final,cmap="gray")
plt.title('Top hat ,threshhold')


######### noise filter

path_cyg='cygnus.tif';
cyg=cv.imread(path_cyg)
cyg=cv.cvtColor(cyg, cv.COLOR_BGR2GRAY)
cyg_opened = cv.morphologyEx(cyg, cv.MORPH_OPEN, kernel)
cyg_closed = cv.morphologyEx(cyg_opened, cv.MORPH_CLOSE, kernel)

plt.figure("noise")
plt.imshow(cyg_closed,cmap="gray")
plt.title('Noise reduction')

