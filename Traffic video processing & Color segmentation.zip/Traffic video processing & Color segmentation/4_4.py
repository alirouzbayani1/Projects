import numpy as np
import cv2 as cv
from matplotlib import pyplot as plt 
from astropy.convolution import Gaussian2DKernel



im=cv.imread('new_echo.jpg')
im=cv.cvtColor(im, cv.COLOR_BGR2GRAY)


## canny

im_canny=cv.Canny(im,100,200)

plt.figure('canny')

plt.imshow(im_canny,cmap = 'gray')
plt.title('Canny')



## sobel

sobelx = cv.Sobel(im,cv.CV_64F,1,0,ksize=5)
sobely = cv.Sobel(im,cv.CV_64F,0,1,ksize=5)
sobel= np.sqrt(pow(sobelx, 2.0) + pow(sobely, 2.0))

plt.figure('sobel')

plt.imshow(sobel,cmap = 'gray')
plt.title('Sobel')



### prewitt

horizontal = np.array([[-1, 0, 1], [-1, 0, 1], [-1, 0, 1]])  # s2
vertical = np.array([[-1, -1, -1], [0, 0, 0], [1, 1, 1]])  # s1

prewitt_x = cv.filter2D(im,-1,horizontal)
prewitt_y = cv.filter2D(im,-1,vertical)
prewitt = np.sqrt(pow(prewitt_x, 2.0) + pow(prewitt_y, 2.0))

plt.figure('prewitt')
plt.imshow(prewitt,cmap = 'gray')
plt.title('Prewitt')



### roberts

roberts_h = np.array( [[ 0, 0, 0 ],[ 0, 0, 1 ],[ 0,-1, 0 ]] )
roberts_v = np.array( [[ 0, 0, 0 ],[ 0, 1, 0 ],[ 0, 0,-1 ]] )


roberts_x = cv.filter2D(im,-1,roberts_h)
roberts_y = cv.filter2D(im,-1,roberts_v)

roberts = np.sqrt(pow(roberts_x, 2.0) + pow(roberts_y, 2.0))

plt.figure('roberts')
plt.imshow(roberts,cmap = 'gray')
plt.title('Roberts')



#### LoG


g_mask= Gaussian2DKernel(11)


blur = cv.GaussianBlur(im,(3,3),0)

laplacian = cv.Laplacian(blur,cv.CV_64F)







#laplacian = laplacian/laplacian.max()

plt.figure('Log')
plt.imshow(laplacian,cmap = 'gray')
plt.title('L of G')







