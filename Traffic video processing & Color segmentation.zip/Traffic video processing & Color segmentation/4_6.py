import numpy as np
import cv2 as cv
from matplotlib import pyplot as plt 

jump_0=cv.imread('jump.jpg')

kernel = np.ones((10,10),np.uint8)

blue_image=jump_0[:,:,0]
red_image=jump_0[:,:,2]
green_image=jump_0[:,:,1]

plt.figure('RGB')
plt.subplot(1,3,1)
plt.imshow(blue_image,cmap='gray')
plt.title('Blue ')
plt.subplot(1,3,2)
plt.imshow(red_image,cmap='gray')
plt.title('Red')
plt.subplot(1,3,3)
plt.imshow(green_image,cmap='gray')
plt.title('Green')



_,im_thresh_blue=cv.threshold(blue_image,75,1,cv.THRESH_BINARY_INV)
_,im_thresh_red=cv.threshold(red_image,75,1,cv.THRESH_BINARY_INV)
_,im_thresh_green=cv.threshold(green_image,75,1,cv.THRESH_BINARY_INV)

plt.figure('thresh')
plt.imshow(im_thresh_blue,cmap='gray')
plt.title('Blue threshhold')


#plt.subplot(1,3,2)
#plt.imshow(im_thresh_blue,cmap='gray')
#plt.subplot(1,3,3)
#plt.imshow(im_thresh_green,cmap='gray')



#im_closed = cv.morphologyEx(im_thresh_red, cv.MORPH_CLOSE, kernel)
#mask = cv.morphologyEx(im_closed, cv.MORPH_OPEN, kernel)



mask = cv.morphologyEx(im_thresh_blue, cv.MORPH_CLOSE, kernel)



RGB_mask = np.zeros((mask.shape[0], mask.shape[1], 3), "uint8") 
RGB_mask [:,:,0] = mask
RGB_mask [:,:,1] = mask
RGB_mask [:,:,2] = mask

plt.figure('mask')
plt.imshow(mask,cmap='gray')
plt.title('Mask')



segmented=RGB_mask*jump_0

cv.imshow('segmented',segmented)




#green_value=np.sum(green_image)
#red_value=np.sum(red_image)
#
#if green_value >red_value:
#    blueness=blue_image-green_image
#
#if red_value >green_value:
#    blueness=blue_image-red_image
#    
#
#cv.imshow('blue',blueness)











