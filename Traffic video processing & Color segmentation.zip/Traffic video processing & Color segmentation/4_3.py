import cv2
import numpy as np
from matplotlib import pyplot as plt
 
cap = cv2.VideoCapture('HW.avi')
(f,first)=cap.read()
first=cv2.cvtColor(first, cv2.COLOR_BGR2GRAY)
while 1:
    
    (f,frame) = cap.read()
    frame_color=frame
    frame=cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
    difference=cv2.absdiff(first,frame)
    (thresh, difference) = cv2.threshold(difference, 30, 70, cv2.THRESH_BINARY)    
    a_1=frame_color[:,:,0]*difference
    a_2=frame_color[:,:,1]*difference
    a_3=frame_color[:,:,2]*difference    
    frame_color[:,:,1]=frame_color[:,:,1]+a_2                
    if frame is None:
        break        
    cv2.imshow('frame',frame_color)  
    if cv2.waitKey(50) & 0xff ==ord('q'):
        break        
cap.release()
cv2.destroyAllWindows()