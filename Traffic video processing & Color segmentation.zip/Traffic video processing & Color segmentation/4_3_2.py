import cv2
import numpy as np
from matplotlib import pyplot as plt
 

cap = cv2.VideoCapture('HW.avi')

## background model

frameIds = cap.get(cv2.CAP_PROP_FRAME_COUNT) * np.random.uniform(size=100)

frames = []
for fid in frameIds:
    cap.set(cv2.CAP_PROP_POS_FRAMES, fid)
    ret, frame = cap.read()
    frames.append(frame)

medianFrame = np.median(frames, axis=0).astype(dtype=np.uint8)


bg_frame=cv2.cvtColor(medianFrame, cv2.COLOR_BGR2GRAY)


kernel = np.ones((5,5),np.uint8)


while True:
    
    _,frame = cap.read()
    frame_color=frame
    frame=cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)

    difference=cv2.absdiff(bg_frame,frame)
    (thresh, difference) = cv2.threshold(difference, 30, 100, cv2.THRESH_BINARY)
    difference = cv2.morphologyEx(difference, cv2.MORPH_OPEN, kernel)
    difference = cv2.morphologyEx(difference, cv2.MORPH_CLOSE, kernel)
    
    for i in range(0,np.shape(frame)[0]):
        for j in range(0,np.shape(frame)[1]):
            if difference[i][j]!=0:
                frame_color[i][j][0]=150
                frame_color[i][j][2]=frame_color[i][j][2]*0.3
                frame_color[i][j][1]=frame_color[i][j][1]*0.3
                
                
                
    
    
    
    
    if frame is None:
        break
    

    
    cv2.imshow('first_frame',bg_frame)
    cv2.imshow('frame',frame_color)
    cv2.imshow('difference',difference)
  
    
    
    
    if cv2.waitKey(50) & 0xff ==ord('q'):
        break
    
cap.release()
cv2.destroyAllWindows()