import numpy as np
import cv2 as cv
import matplotlib.pyplot as plt

###########a

kernel = np.ones((10,10),np.uint8)


path='object.jpg';
img=cv.imread(path)
img=cv.cvtColor(img, cv.COLOR_BGR2GRAY)


img_erode = cv.erode(img,kernel,iterations = 1)
img_dialated = cv.dilate(img,kernel,iterations = 1)

img_opened = cv.morphologyEx(img, cv.MORPH_OPEN, kernel)
img_closed = cv.morphologyEx(img, cv.MORPH_CLOSE, kernel)


plt.figure("Morphological transformations")
plt.subplot(2,2,1)
plt.imshow(img_erode,cmap="gray")
plt.title('erode')
plt.subplot(2,2,2)
plt.imshow(img_dialated,cmap="gray")
plt.title('dialate')
plt.subplot(2,2,3)
plt.imshow(img_opened,cmap="gray")
plt.title('open')
plt.subplot(2,2,4)
plt.imshow(img_closed,cmap="gray")
plt.title('close')






